package com.example.vidify.Models;

import java.io.Serializable;

public class User implements Serializable {
    public String name, email,token,id;
}
